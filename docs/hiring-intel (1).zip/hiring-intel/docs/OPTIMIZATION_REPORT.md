# Optimization report: before / after

Generated from `data/eval/benchmark.csv` (80 runs: 5 scenarios × 3 sizes + one xlarge input, × 5 variants). Each variant adds one lever to the previous one. Mock backend: costs use example prices; latency is simulated (see [COST_AND_LATENCY.md](COST_AND_LATENCY.md)). Re-run `python scripts/benchmark.py` with `LLM_BACKEND=litellm` to replace these with real measurements.

## Headline: baseline scenario, large input (25k candidates, 14.7k notes to label)

| Variant | Lever added | Run cost (USD) | vs previous | E2E latency | Input tokens | Golden pass |
| --- | --- | --- | --- | --- | --- | --- |
| all_large | none: everything on the large model, LLM labels notes | 0.1301 | — | 101.3 s | 270,845 | 18/18 |
| routed | **A. model routing** | 0.0962 | −26% | 100.4 s | 270,773 | — |
| routed_compressed | **B. context compression** | 0.0872 | −9% | 98.1 s | 262,710 | 15/18 before fix, 18/18 after |
| optimized | **C. OpenJev for simple decisions** | 0.0160 | −82% | 15.9 s | 6,538 | 18/18 |
| optimized_cached | **D. response cache (re-run)** | 0.0003 | −98% | 3.5 s | 6,525 | 18/18 |

Overall: **$0.1301 → $0.0160 per run (−88%) and 101 s → 16 s E2E** with no golden-set regression on medium and large inputs.

## How cost scales with input size (baseline scenario)

| Input | Candidates | all_large | routed | routed_compressed | optimized |
| --- | --- | --- | --- | --- | --- |
| small | 1.2k | $0.0486 | $0.0242 | $0.0193 | $0.0158 |
| medium | 6.3k | $0.0676 | $0.0419 | $0.0337 | $0.0159 |
| large | 25k | $0.1301 | $0.0962 | $0.0872 | $0.0160 |
| xlarge | 84k | $0.3201 | $0.2622 | $0.2515 | $0.0160 |

With an LLM labelling notes, cost grows linearly with the number of notes. With OpenJev the run cost is flat: agents see aggregated features whose size does not depend on candidate count.

## Per lever

**A. Routing (−26% on large input, −50% on small).** Panel Load, Pipeline Health and Sourcing go to the small model on rule scores; Rejection and Offers go large through an OpenJev tie-break ("does this need causal reasoning?"). Golden score unchanged on medium/large.

**B. Compression (−9% of run cost here; insight-agent input tokens −28% on small and −58% on large inputs: 7,933 → 5,697 and 13,843 → 5,818).** Run cost moves less because, in this variant, note labelling still dominates. Top-N rows, pruned columns, `top_k` 2. The golden set caught a regression: trimming the panel table to the top and bottom 8 interviewers distorted the median, so Panel Load stopped flagging overload (15/18). Fix: compute the panel median before trimming and pass it as a column. After the fix: 18/18.

**C. OpenJev (−82%).** Labelling 14.7k free-text notes moved from 295 batched small-LLM calls to local NLI decisions. It also removed ~82 s of simulated E2E latency. In this build OpenJev ran as the keyword fallback (no Hugging Face access); label accuracy vs planted truth was 0.92 with the 3 deliberately ambiguous note templates (about 8% of notes) left `unclassified` instead of guessed. Measure the real model's accuracy and CPU time before you quote this lever.

**D. Cache (−98% on repeats).** Identical prompt + model returns the stored response. It helps re-runs on unchanged data and the demo; it does nothing on fresh data, so it is reported separately.

## What I would not do

- Downgrade Rejection/Offers to the small model just because the mock judge scores them 0.97: the mock judge cannot see reasoning quality. Decide with a real judge and human ratings.
- Cache across data refreshes: the key includes the features text, so this is safe, but a TTL is still wise.
