from hiring_intel.openjev import KeywordFallback, OpenJevDecider


def test_fallback_choose_and_escalate():
    d = OpenJevDecider(KeywordFallback())
    r = d.choose("t", "Weak on SQL joins and indexing.", "reason?", ["fundamentals", "coding"],
                 keywords={"fundamentals": ["sql", "joins"], "coding": ["bugs"]})
    assert r.choice == "fundamentals" and not r.escalated and r.backend == "keyword-fallback"
    amb = d.choose("t", "Not the right fit.", "reason?", ["fundamentals", "coding"],
                   keywords={"fundamentals": ["sql"], "coding": ["bugs"]})
    assert amb.escalated
