"""LangGraph orchestrator.

ingest -> enrich (OpenJev) -> 5 insight agents in parallel -> evaluate -> [retry low scorers on large]
       -> human_review (HITL) -> optimize -> persist

State carries only paths, configs and JSON-able dicts, so it can be checkpointed (needed for HITL
interrupt/resume). A failed agent writes a 'failed' output instead of raising.
"""
from __future__ import annotations

import datetime as dt
import operator
import time
import uuid
from typing import Annotated, TypedDict

from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import Command, interrupt

from hiring_intel import hitl
from hiring_intel.agents.evaluator import evaluate_one
from hiring_intel.agents.insight_agents import AGENTS
from hiring_intel.agents.optimizer import optimize
from hiring_intel.contracts import AgentOutput, Evidence, ReviewItem
from hiring_intel.enrich import enrich
from hiring_intel.ingest import load_all
from hiring_intel.observability import execute, log_timing
from hiring_intel.openjev import decider


def merge(old: dict | None, new: dict | None) -> dict:
    return {**(old or {}), **(new or {})}


class RunState(TypedDict, total=False):
    run_id: str
    cfg: dict
    enrich: dict
    outputs: Annotated[dict, merge]
    evals: Annotated[dict, merge]
    retried: list[str]
    review: list[dict]
    suggestions: list[dict]
    errors: Annotated[list, operator.add]


def _ms(t0: float) -> int:
    return int((time.perf_counter() - t0) * 1000)


# ------------------------------------------------------------------ nodes
def ingest_node(s: RunState):
    t0 = time.perf_counter()
    load_all(s["cfg"]["data_path"])
    log_timing(s["run_id"], "ingest", "-", _ms(t0), 0)
    return {}


def enrich_node(s: RunState):
    t0 = time.perf_counter()
    info = enrich(load_all(s["cfg"]["data_path"]), s["run_id"], decider(), mode=s["cfg"]["classify"])
    log_timing(s["run_id"], "enrich", "-", _ms(t0), 0)
    return {"enrich": info}


def _run_agent(name: str, s: RunState, force_tier: str | None = None, last_eval: float | None = None) -> AgentOutput:
    cfg = s["cfg"]
    if cfg.get("crash_agent") == name and not force_tier:
        return AgentOutput(agent=name, run_id=s["run_id"], status="failed", error="RuntimeError: injected crash")
    if cfg.get("transport") == "a2a":
        from hiring_intel.a2a import call_agent
        out = call_agent(name, {"data_path": cfg["data_path"], "run_id": s["run_id"], "force_tier": force_tier
                                or cfg.get("force_tier"), "compress": cfg["compress"], "use_cache": cfg["use_cache"],
                                "last_eval": last_eval})
    else:
        out = AGENTS[name].run(load_all(cfg["data_path"]), s["run_id"], force_tier=force_tier or cfg.get("force_tier"),
                               compress=cfg["compress"], use_cache=cfg["use_cache"], last_eval=last_eval)
    if cfg.get("inject_fault") == name and not force_tier and out.insights:
        # fabricated numbers: the evaluator should catch them and trigger a retry on the large model
        for ins in out.insights:
            ins.evidence += [Evidence(metric="industry_hire_rate", value=v, segment={"note": "invented"})
                             for v in (0.777, 0.913, 0.4242)]
    return out


def make_agent_node(name: str):
    def node(s: RunState):
        out = _run_agent(name, s)
        llm = out.cost_of_insight.latency_ms if out.cost_of_insight else 0
        log_timing(s["run_id"], "agents", name, out.compute_ms, llm)
        errs = [f"{name}: {out.error}"] if out.status == "failed" else []
        return {"outputs": {name: out.model_dump()}, "errors": errs}
    return node


def evaluate_node(s: RunState):
    t0 = time.perf_counter()
    data = load_all(s["cfg"]["data_path"])
    todo = [a for a in s["outputs"] if a not in s.get("evals", {}) or a in s.get("retried", [])]
    res = {}
    for a in todo:
        out = AgentOutput.model_validate(s["outputs"][a])
        res[a] = evaluate_one(AGENTS[a], out, data, s["run_id"], s["cfg"]["compress"]).model_dump()
    log_timing(s["run_id"], "evaluate", "-", _ms(t0), 0)
    return {"evals": res}


def needs_retry(s: RunState) -> str:
    low = [a for a, r in s["evals"].items() if r["overall"] < 0.6 and a not in s.get("retried", [])]
    return "retry" if low else "human_review"


def retry_node(s: RunState):
    low = [a for a, r in s["evals"].items() if r["overall"] < 0.6 and a not in s.get("retried", [])]
    new = {}
    for a in low:                                      # sequential here; small number of agents
        out = _run_agent(a, s, force_tier="large", last_eval=s["evals"][a]["overall"])
        log_timing(s["run_id"], "retry", a, out.compute_ms, out.cost_of_insight.latency_ms if out.cost_of_insight else 0)
        new[a] = out.model_dump()
    return {"outputs": new, "retried": s.get("retried", []) + low}


def human_review_node(s: RunState):
    t0 = time.perf_counter()
    outs = {a: AgentOutput.model_validate(o) for a, o in s["outputs"].items() if o["status"] != "failed"}
    items = hitl.build_queue(s["run_id"], outs, s["evals"])
    mode = s["cfg"]["hitl_mode"]
    pend = [i for i in items if i.status == "pending"]
    if pend and mode == "interrupt":
        # pauses the graph; the caller resumes with Command(resume={item_id: {"action":..., "note":...}})
        decisions = interrupt({"pending": [i.model_dump() for i in pend]})
        for iid, d in (decisions or {}).items():
            hitl.apply_decision(iid, d.get("action", "approved"), d.get("reviewer", "human"), d.get("note", ""),
                                d.get("edited_recommendation"))
    elif pend and mode == "simulate":
        for i in pend:
            act, note = hitl.simulated_reviewer(i, s["evals"].get(i.agent, {}).get("overall", 0))
            hitl.apply_decision(i.item_id, act, "simulated-policy", note)
    log_timing(s["run_id"], "human_review", "-", _ms(t0), 0)
    final = [ReviewItem.model_validate_json(j).model_dump() for j in
             hitl.query("SELECT json FROM review_queue WHERE run_id=?", (s["run_id"],)).json]
    return {"review": final}


def optimize_node(s: RunState):
    t0 = time.perf_counter()
    sug = optimize(s["run_id"], s["evals"])
    log_timing(s["run_id"], "optimize", "-", _ms(t0), 0)
    return {"suggestions": [i.model_dump() for i in sug]}


def persist_node(s: RunState):
    import json
    rid = s["run_id"]
    for a, o in s["outputs"].items():
        execute("INSERT INTO agent_outputs VALUES (?,?,?,?)", (rid, a, o["status"], json.dumps(o)))
    for a, e in s["evals"].items():
        execute("INSERT INTO eval_results VALUES (?,?,?,?)", (rid, a, e["overall"], json.dumps(e)))
    from hiring_intel.report import summarize_run
    summarize_run(rid, s)
    return {}


# ------------------------------------------------------------------ graph
def build(checkpointer=None):
    g = StateGraph(RunState)
    g.add_node("ingest", ingest_node)
    g.add_node("enrich", enrich_node)
    for name in AGENTS:
        g.add_node(name, make_agent_node(name))
        g.add_edge("enrich", name)                     # fan-out: five agents in parallel
        g.add_edge(name, "evaluate")                   # fan-in
    g.add_node("evaluate", evaluate_node)
    g.add_node("retry", retry_node)
    g.add_node("human_review", human_review_node)
    g.add_node("optimize", optimize_node)
    g.add_node("persist", persist_node)
    g.add_edge(START, "ingest")
    g.add_edge("ingest", "enrich")
    g.add_conditional_edges("evaluate", needs_retry, {"retry": "retry", "human_review": "human_review"})
    g.add_edge("retry", "evaluate")
    g.add_edge("human_review", "optimize")
    g.add_edge("optimize", "persist")
    g.add_edge("persist", END)
    return g.compile(checkpointer=checkpointer or InMemorySaver())


_APP = None


def app():
    global _APP
    if _APP is None:
        _APP = build()
    return _APP


def run(data_path: str = "data/raw/baseline_small", *, scenario: str = "", size: str = "", variant: str = "routed",
        force_tier: str | None = None, compress: bool = False, use_cache: bool = False, classify: str = "openjev",
        hitl_mode: str = "queue", transport: str = "local", inject_fault: str | None = None,
        crash_agent: str | None = None, run_id: str | None = None, graph=None) -> dict:
    run_id = run_id or f"{variant}-{dt.datetime.now().strftime('%m%d%H%M%S')}-{uuid.uuid4().hex[:4]}"
    cfg = dict(data_path=data_path, scenario=scenario, size=size, variant=variant, force_tier=force_tier,
               compress=compress, use_cache=use_cache, classify=classify, hitl_mode=hitl_mode, transport=transport,
               inject_fault=inject_fault, crash_agent=crash_agent, started=time.perf_counter())
    g = graph or app()
    state = g.invoke({"run_id": run_id, "cfg": cfg, "outputs": {}, "evals": {}, "errors": [], "retried": []},
                     {"configurable": {"thread_id": run_id}})
    state["run_id"] = run_id
    return state


def resume(run_id: str, decisions: dict, graph=None) -> dict:
    """Resume a run paused at human_review (hitl_mode='interrupt')."""
    g = graph or app()
    return g.invoke(Command(resume=decisions), {"configurable": {"thread_id": run_id}})
