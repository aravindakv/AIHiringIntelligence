"""Enrichment: fill missing rejection / decline reasons by classifying free-text notes with OpenJev.

This is the highest-volume "simple decision" in the system: thousands of notes, a closed label
set, no generation needed. Running it on an LLM would cost tokens per note; OpenJev costs $0 API.
"""
from __future__ import annotations

import time
from pathlib import Path

import pandas as pd

from pydantic import BaseModel

from hiring_intel.ingest import HiringData
from hiring_intel.llm import call_structured, model_for, price_usd
from hiring_intel.observability import log_decision
from hiring_intel.openjev import KeywordFallback, OpenJevDecider


class NoteLabels(BaseModel):
    labels: list[str]

REJECTION_LABELS = {
    "JD mismatch": ["jd", "job description", "posting", "does not match", "different scope", "native"],
    "fundamentals": ["basic", "fundamentals", "data structures", "complexity", "sql", "joins", "indexing",
                     "recursion", "hashing"],
    "system design": ["design", "scaling", "partition", "consistency", "failure modes"],
    "communication": ["explanations", "clarify", "rambled", "structure the answer", "listen"],
    "coding": ["coding", "code", "bugs", "edge cases", "tests"],
    "experience gap": ["junior", "years of experience", "ownership"],
    "culture add": ["collaboration", "dismissive", "feedback"],
}
DECLINE_LABELS = {
    "compensation": ["below", "compensation", "ctc", "20% more", "expectation"],
    "competing offer": ["another company", "competing"],
    "timing": ["too long", "notice period", "start date", "moved on"],
    "location": ["relocate", "remote", "location"],
}


def _classify(decider: OpenJevDecider, run_id: str, task: str, notes: pd.Series, labels: dict,
              mode: str = "openjev") -> dict[str, str]:
    mapping = {}
    counts = notes.value_counts()
    if mode == "llm":
        # the expensive alternative (benchmark baseline): real notes are mostly unique, so every note
        # goes to the LLM, 50 notes per call
        kw = OpenJevDecider(KeywordFallback())
        notes_l = [str(n) for n in notes.tolist()]
        for b in range(0, len(notes_l), 50):
            batch = notes_l[b:b + 50]
            parsed, _ = call_structured(
                agent=f"enrich:{task}", run_id=run_id, model=model_for("small"),
                system=f"Label each numbered note with exactly one of: {list(labels)}. "
                       "Return {\"labels\": [...]} in the same order.",
                user="\n".join(f"{i + 1}. {t}" for i, t in enumerate(batch)), schema=NoteLabels,
                mock_fn=lambda batch=batch: NoteLabels(labels=[
                    kw.choose(task, t, "reason?", list(labels), keywords=labels).choice for t in batch]))
            for t, lab in zip(batch, parsed.labels):
                mapping[t] = lab
        return mapping
    for note, n in counts.items():                      # unique notes only; results memoised
        d = decider.choose(task, str(note), "What is the main reason described in this note?",
                           list(labels), keywords=labels)
        log_decision(run_id, d, n_items=int(n))
        # low confidence: don't force a label; the note stays visible as "unclassified"
        mapping[note] = "unclassified" if d.escalated else d.choice
    return mapping


def enrich(data: HiringData, run_id: str, decider: OpenJevDecider, mode: str = "openjev") -> dict:
    t0 = time.perf_counter()
    ev = data.stage_events
    if "reason" not in ev.columns:
        ev["reason_source"] = "structured"
        ev["reason"] = ev["rejection_reason"]
    need = ev[(ev.result == "reject") & ev.rejection_reason.isna() & ev.rejection_note.notna()]
    rmap = _classify(decider, run_id, "classify_rejection_note", need.rejection_note, REJECTION_LABELS, mode)
    ev.loc[need.index, "reason"] = need.rejection_note.map(rmap)
    ev.loc[need.index, "reason_source"] = mode

    of = data.offers
    if "reason" not in of.columns:
        of["reason"] = of["decline_reason"]
    dneed = of[(of.status == "declined") & of.decline_reason.isna() & of.decline_note.notna()]
    dmap = _classify(decider, run_id, "classify_decline_note", dneed.decline_note, DECLINE_LABELS, mode)
    of.loc[dneed.index, "reason"] = dneed.decline_note.map(dmap)

    # what an LLM would have cost for the same job (one small-model call per note, ~120 tokens in / 10 out)
    n_items = len(need) + len(dneed)
    small = model_for("small")
    llm_usd = price_usd(small, 120 * n_items, 10 * n_items)
    accuracy = _accuracy(data)
    return {"classified": n_items, "unique_notes": len(rmap) + len(dmap),
            "backend": "llm-small" if mode == "llm" else decider.backend.name,
            "compute_ms": int((time.perf_counter() - t0) * 1000), "llm_equivalent_usd": round(llm_usd, 4),
            "accuracy_vs_truth": accuracy}


def _accuracy(data: HiringData) -> float | None:
    f = Path(data.path) / "_labels.csv"
    if not f.exists():
        return None
    lab = pd.read_csv(f)
    rej = lab[lab.kind == "rejection"].merge(
        data.stage_events[data.stage_events.reason_source != "structured"][["candidate_id", "stage", "reason"]],
        on=["candidate_id", "stage"])
    return round(float((rej.true_reason == rej.reason).mean()), 3) if len(rej) else None
