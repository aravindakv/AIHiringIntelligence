"""Hiring Intelligence System.

Loads the repo's .env on first import, so settings such as LLM_BACKEND, OPENAI_API_KEY, LANGSMITH_API_KEY
and HF_TOKEN work for plain `python ...` runs too (Docker Compose passes .env via env_file). Variables
already set in the shell win over .env.
"""
from pathlib import Path

try:
    from dotenv import load_dotenv

    load_dotenv(Path(__file__).resolve().parent.parent / ".env", override=False)
except ImportError:  # python-dotenv not installed: rely on the shell environment
    pass
