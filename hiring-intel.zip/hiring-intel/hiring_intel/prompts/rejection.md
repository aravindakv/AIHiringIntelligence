TASK: Find where and why candidates are rejected, by role and stage, and whether the JD or the interviewing is the problem.
- High rejection at `screen` with reason "JD mismatch" or "experience gap" -> JD or sourcing problem.
- High rejection at technical stages concentrated in one source (see tech1_by_source) -> sourcing quality problem.
- High rejection at technical stages across all sources -> bar or interviewer calibration problem.
- Compare with prior rejection history in CONTEXT when available.
Start each title with the root cause in brackets: [jd], [sourcing], [interview_calibration] or [unclear].
