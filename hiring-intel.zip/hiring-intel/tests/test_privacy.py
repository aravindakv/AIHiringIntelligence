"""Names are in the CSVs for demos; they must never appear in any prompt sent to a model."""
import pandas as pd

from hiring_intel import llm


def test_no_names_in_any_prompt(monkeypatch):
    prompts = []
    real = llm.call_structured

    def spy(**kw):
        prompts.append(kw["system"] + "\n" + kw["user"])
        return real(**kw)

    import hiring_intel.agents.base as base
    import hiring_intel.agents.optimizer as opt
    import hiring_intel.agents.router as router
    import hiring_intel.enrich as enrich
    for mod in (base, opt, router, enrich):
        monkeypatch.setattr(mod, "call_structured", spy)

    from hiring_intel.graph import run
    # all_large-style run: uncompressed features and LLM note labelling send the most text
    run("data/raw/baseline_small", variant="privacy", compress=False, classify="llm", force_tier="large")
    assert prompts, "no prompts captured"

    raw = "data/raw/baseline_small/"
    names = set(pd.read_csv(raw + "candidates.csv").candidate_name)
    names |= set(pd.read_csv(raw + "interviewers.csv").name)
    names |= set(pd.read_csv(raw + "requisitions.csv").hiring_manager)
    text = "\n".join(prompts)
    leaked = sorted(n for n in names if n in text)
    assert not leaked, f"names leaked into prompts: {leaked[:5]}"
