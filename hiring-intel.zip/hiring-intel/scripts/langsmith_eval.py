"""Run the golden set as a LangSmith experiment.

    # online: needs LANGSMITH_API_KEY; creates dataset 'hiring-intel-golden' once, one experiment per call
    python scripts/langsmith_eval.py --variant optimized --size medium
    python scripts/langsmith_eval.py --variant all_large --size medium     # then compare both in the UI

    # offline: same target and evaluators, scored locally, nothing uploaded
    python scripts/langsmith_eval.py --offline
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from hiring_intel.evals.langsmith_eval import run_experiment, run_offline  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--size", default="medium")
ap.add_argument("--variant", default="optimized")
ap.add_argument("--offline", action="store_true")
a = ap.parse_args()

if a.offline:
    rows = run_offline(a.size, a.variant)
else:
    res = run_experiment(a.size, a.variant)
    rows = [{"case_id": r["example"].inputs["case_id"],
             **{e.key: e.score for e in r["evaluation_results"]["results"]}} for r in res]
    print("experiment:", getattr(res, "experiment_name", "see the LangSmith UI"))

print(f"{'case':10} {'pass':>4} {'grounded':>8} {'eval':>5}")
for r in rows:
    print(f"{r['case_id']:10} {r.get('golden_pass'):>4} {r.get('numbers_grounded'):>8} {r.get('eval_agent_overall'):>5}")
print(f"\ngolden pass rate: {sum(1 for r in rows if r.get('golden_pass'))}/{len(rows)}")
