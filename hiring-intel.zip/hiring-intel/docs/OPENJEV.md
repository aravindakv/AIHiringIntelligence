# OpenJev for simple decisions

Code: [`hiring_intel/openjev.py`](../hiring_intel/openjev.py), service: [`services/openjev_server.py`](../services/openjev_server.py).

## What it is

OpenJev ([huggingface.co/AlexWortega/openjev](https://huggingface.co/AlexWortega/openjev), MIT licence per its model card) is Qwen3.5 fine-tuned as an NLI **cross-encoder**. Given a premise and a hypothesis it returns P(contradiction), P(entailment), P(neutral). To decide between options you score one hypothesis per option and take the highest entailment. Write each hypothesis as a plain statement ("The candidate's system design was weak."), not as a question with an answer appended; the measurements below show why. It does not generate text, it is deterministic, and its option scores do not depend on option order.

Checkpoints that exist in the repo (checked October 2026): `qwen3.5-0.8b-nli-v2s-long` (CPU-friendly; the default here), `qwen3.5-4b-nli-v2` (reads text and images; use on a GPU), `qwen3.5-4b-nli` (v1, text only) and `qwen3.5-35b-a3b-nli` (35B mixture-of-experts). The model card also describes `…-nli-v5` checkpoints that are not in the repo; loading one fails with a misleading tokenizer error. `LocalOpenJev` now checks the subfolder first and lists the real ones. All of them use the labels contradiction / entailment / neutral and `nli_template = "Premise: {premise}\nHypothesis: {hypothesis}"`.

## Where this system uses it

| Decision | Premise | Options | Why not the LLM |
| --- | --- | --- | --- |
| Label rejection notes | interviewer's free-text note | 7 reasons | Thousands of items per run; closed label set |
| Label decline notes | recruiter's note | comp / competing / timing / location | Same |
| Routing tie-break | task profile text | yes / no "needs causal reasoning?" | Runs before every borderline agent; must be ~free |
| HITL sensitivity | the recommendation | yes / no "changes comp, headcount or workload?" | Gate on every insight |
| Actionability pre-check | the recommendation | yes / no "specific and actionable?" | Cheap signal for the evaluator |

Every decision is logged to the `decisions` table with its backend, confidence and whether it **escalated**. A decision escalates when its confidence is below the floor for its option count (`min_confidence` 0.55 for yes/no, `min_confidence_multi` 0.30 for 3+ options, because probability spreads across more options), or when it picks the **abstain** option. Note labelling adds an `unclear` option ("The note does not name any specific skill, problem or reason.") so a vague note can say so instead of being forced into a label. Note labels become `unclassified`, routing falls back to a small-LLM call, and HITL marks the item "sensitivity unclear" for a human.

## Backends

| Backend | When | Set up |
| --- | --- | --- |
| `http` | Docker Compose `openjev` service (recommended) | `docker compose --profile openjev up -d`, `OPENJEV_URL=http://openjev:8200` |
| `local` | Weights loaded in-process | `pip install -r requirements-ml.txt` |
| `fallback` | No weights available (offline CI, this build) | none; keyword scorer with the same interface |
| `auto` (default) | http if `OPENJEV_URL` set, else local, else fallback | — |

The committed benchmark used **fallback** because the build machine could not reach Hugging Face. The real model was then measured on a laptop CPU (below).

## Measured with the real model (`qwen3.5-0.8b-nli-v2s-long`, CPU, October 2026)

Rejection notes on `baseline_small`: 710 notes, 21 unique note texts, 18 of them with a clear reason. Accuracy is weighted by how often each note occurs.

| Setup | Accuracy on clear notes |
| --- | --- |
| question hypotheses (`"What is the main reason…? Answer: fundamentals"`), floor 0.55 | 0.41 (the first run reported 0.385 overall) |
| question hypotheses, no floor | 0.73 |
| **plain-statement hypotheses**, no floor | **1.00** |
| plain-statement hypotheses, floor 0.30 | **1.00** |
| plain-statement + `unclear` option, through `enrich()` on `baseline_large` (14.7k notes) | **1.00** when labelled; 17.7% escalated (8% are truly ambiguous) |

What this shows:

1. **Hypothesis wording mattered most.** Labels such as "culture add" or "JD mismatch" in a question template lost to near-synonyms; a one-sentence description of each label fixed every clear note.
2. **A yes/no floor kills multi-class decisions.** With 7 options, correct answers often scored 0.36–0.5. The 0.55 floor marked them `unclassified`, and accuracy counts that as wrong.
3. **Ambiguous notes are not escalated by a floor alone.** "Mixed signals across the loop" got `culture add` at 0.73. The raw entailment was 0.13 (the model did not believe it), but normalising across options hid that. The `unclear` abstain option fixes that: nothing is mislabelled now. It is too cautious, though. It escalates 17.7% of notes against 8% truly ambiguous ones, so some clear notes go to a human. The likely culprits are the notes whose raw entailment was lowest ("Applied for a different scope than the posting", "Expected Kotlin/Swift depth per job description", "Could not partition the service…"). Tune `UNCLEAR_HYPOTHESIS` and those label sentences on your own labelled notes.

**Latency:** about 8.4 s per unique note on CPU with 7 hypotheses, 10.4 s with 8 (the `unclear` option adds one; scored in one batch through the HTTP service). The system memoises by note text, so the synthetic data (25 templates) labels in about 3–4 minutes at any size. Real notes are mostly unique: 14.7k notes would take about 34 hours on that CPU. For production, run the `openjev` service on a GPU, or keep note labelling on the small LLM and use OpenJev only for the low-volume yes/no gates (routing, HITL sensitivity, actionability), where 2–3 s per decision is acceptable.

## Loading the model directly

```python
from transformers import AutoModelForSequenceClassification, AutoTokenizer
sub = "qwen3.5-0.8b-nli-v2s-long"
tok = AutoTokenizer.from_pretrained("AlexWortega/openjev", subfolder=sub)
model = AutoModelForSequenceClassification.from_pretrained("AlexWortega/openjev", subfolder=sub)
text = model.config.nli_template.format(premise="...", hypothesis="...")
```

`LocalOpenJev` uses `config.nli_template` when present and finds the entailment index from `config.id2label` (model card order: contradiction, entailment, neutral).

## Caveats to put in your eval notes

- **Calibration:** probabilities are not calibrated for your labels. Tune `min_confidence_multi` and the hypothesis sentences on 50 hand-labelled notes; `enrich()` reports `accuracy_when_labelled` and `escalated_share` separately so you can see which way a change moved.
- **Prompt injection:** the model card reports that one adversarial line sharply lowers accuracy. Never use OpenJev alone as a safety gate; pair it with deterministic checks (the HITL policy also uses severity, confidence and eval flags).
- **Benchmark contamination:** the v5 checkpoints were trained on test splits of public benchmarks (per the card), so public benchmark scores are not evidence. Your own labelled notes are.
- **Licence:** the Hugging Face weights are MIT per the card. A separate Docker Hub image (`ai/openjev`) states CC BY-NC 4.0 for its source weights; check which artefact you deploy.
- **Cost model:** $0 API, but CPU/GPU time: about 8.4 s per 7-option note on a laptop CPU. `enrich()` reports `ms_per_unique_note`; multiply by your number of unique notes before choosing this lever.
