---
doc_type: rejection_history
agents: [rejection]
role: Data
period: 2026-Q1
---
# Rej Hist Data
Rejection history Q1 2026: Data tech_1 failures concentrated in candidates from two agencies; adding a SQL pre-screen reduced tech_1 failure from 62% to 38%.
