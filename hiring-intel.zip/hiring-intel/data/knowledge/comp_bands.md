---
doc_type: offer_history
agents: [offers]
role: all
period: 2026-Q1
---
# Comp Bands
Compensation band guidance: approve up to 10% above band midpoint for senior engineers with a competing offer. Offer approvals should complete within 48 hours; every extra week of delay lowers acceptance.
