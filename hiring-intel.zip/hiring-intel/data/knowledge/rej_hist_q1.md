---
doc_type: rejection_history
agents: [rejection]
role: Mobile
period: 2026-Q1
---
# Rej Hist Q1
Rejection history Q1 2026: Mobile screen rejection was 35%, mostly 'experience gap'. A JD rewrite in 2025 that listed must-have native skills cut screen rejections by a third within one quarter.
