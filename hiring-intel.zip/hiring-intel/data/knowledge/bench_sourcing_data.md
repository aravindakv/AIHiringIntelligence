---
doc_type: benchmark
agents: [sourcing, rejection]
role: Data
period: 2026-Q1
---
# Bench Sourcing Data
Sourcing benchmark (illustrative) for Data roles. Agency candidates historically fail SQL and statistics fundamentals more often than referrals. Require a take-home or SQL screen before agency candidates reach tech_1.
