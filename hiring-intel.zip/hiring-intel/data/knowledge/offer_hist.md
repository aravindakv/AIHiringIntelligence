---
doc_type: offer_history
agents: [offers]
role: all
period: 2026-Q1
---
# Offer Hist
Offer outcome history (illustrative): when the offer is below 90% of the candidate's expected CTC, acceptance falls to roughly one in four. Offers at or above 95% of expectation are accepted about 80% of the time.
