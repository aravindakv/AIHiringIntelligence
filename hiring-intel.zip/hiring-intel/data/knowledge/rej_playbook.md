---
doc_type: playbook
agents: [rejection]
role: all
period: 2026-Q1
---
# Rej Playbook
Diagnosis playbook: high screen rejection with 'JD mismatch' means fix the JD or sourcing filters; high technical rejection in one source means fix that source; high technical rejection across all sources means recalibrate the bar or the interviewers (run a calibration session with scored recordings).
