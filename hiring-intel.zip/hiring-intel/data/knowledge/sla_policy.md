---
doc_type: sla
agents: [pipeline, panel_load]
role: all
period: 2026-Q1
---
# Sla Policy
Stage SLA policy: applied 6 days, screen 6, tech_1 7, tech_2 7, onsite 7, offer 5. A stage is in breach when more than 30% of candidates exceed its SLA. Requisitions open over 45 days (60 for senior) need an EM review.
