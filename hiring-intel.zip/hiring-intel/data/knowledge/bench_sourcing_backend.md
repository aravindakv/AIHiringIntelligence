---
doc_type: benchmark
agents: [sourcing]
role: Backend
period: 2026-Q1
---
# Bench Sourcing Backend
Sourcing benchmark (illustrative) for Backend roles. Referral-to-hire conversion is typically 8-12%; job boards convert at 2-4%. Referral candidates reach onsite about twice as often. Agency fees run ~15% of first-year CTC, so agencies should be reserved for niche or senior searches.
