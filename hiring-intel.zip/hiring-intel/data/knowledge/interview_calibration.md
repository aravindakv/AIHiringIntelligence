---
doc_type: playbook
agents: [rejection, panel_load]
role: all
period: 2026-Q1
---
# Interview Calibration
Interviewer calibration: run a monthly calibration with 3 scored recordings per stage; flag interviewers whose pass rate deviates more than 20 points from the panel average.
