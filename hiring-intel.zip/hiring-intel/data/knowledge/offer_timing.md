---
doc_type: offer_history
agents: [offers, pipeline]
role: all
period: 2026-Q1
---
# Offer Timing
Offer timing: candidates who wait more than 7 days for an offer decision are twice as likely to decline for 'timing' or a competing offer. Pre-approve bands before the onsite.
