---
doc_type: benchmark
agents: [sourcing]
role: SRE
period: 2026-Q1
---
# Bench Sourcing Sre
Sourcing benchmark (illustrative) for SRE roles. Expect 60-90 day time-to-fill. Referral and community channels (meetups, open source) outperform job boards for on-call experienced SREs.
