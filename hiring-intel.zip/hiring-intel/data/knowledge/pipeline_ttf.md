---
doc_type: benchmark
agents: [pipeline]
role: all
period: 2026-Q1
---
# Pipeline Ttf
Time-to-fill benchmark (illustrative): Backend/Frontend 35-45 days, Data 45 days, Mobile 40 days, SRE 60-90 days. Onsite scheduling is the most common bottleneck; block recurring onsite slots per week.
