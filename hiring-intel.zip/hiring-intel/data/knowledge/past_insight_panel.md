---
doc_type: past_insight
agents: [panel_load]
role: all
period: 2026-Q1
---
# Past Insight Panel
Past insight (accepted): two interviewers carried 35% of loops in Q1. Moving 3 slots/week each to trained shadows cut their load to policy within 3 weeks and reduced onsite scheduling delay.
