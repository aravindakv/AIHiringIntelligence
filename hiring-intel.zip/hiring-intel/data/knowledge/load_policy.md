---
doc_type: policy
agents: [panel_load]
role: all
period: 2026-Q1
---
# Load Policy
Interviewer load policy: no more than 4 interviews per person per week, and no one above 2x the team median for two weeks running. Rebalance within the same team and level; pair new interviewers with shadows first.
