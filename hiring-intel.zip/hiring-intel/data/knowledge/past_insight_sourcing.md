---
doc_type: past_insight
agents: [sourcing]
role: Backend
period: 2026-Q1
---
# Past Insight Sourcing
Past insight (accepted): Backend referral bonus raised in Q1; referral share rose from 12% to 20% of applicants.
