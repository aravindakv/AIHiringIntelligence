---
doc_type: benchmark
agents: [sourcing]
role: all
period: 2026-Q1
---
# Bench Sourcing All
General sourcing guidance (illustrative). Cut a channel when its hire rate is under half of the best channel for the same role over at least 50 applicants; re-test after one quarter. Shift recruiter hours, not just spend.
